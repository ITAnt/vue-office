package com.example.documentviewer

import android.net.Uri
import android.os.Bundle
import android.util.Base64
import android.util.Log
import android.webkit.JavascriptInterface
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.appcompat.app.AppCompatActivity
import java.io.File

class DocumentViewerActivity : AppCompatActivity() {
    private lateinit var webView: WebView
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_document_viewer)
        
        webView = findViewById(R.id.webview)
        setupWebView()
        
        // 获取要显示的文件路径
        intent.getStringExtra("file_path")?.let { filePath ->
            loadDocument(filePath)
        }
    }
    
    private fun setupWebView() {
        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            allowFileAccess = true
            allowFileAccessFromFileURLs = true
            allowUniversalAccessFromFileURLs = true
            cacheMode = WebSettings.LOAD_DEFAULT
            setSupportZoom(true)
            builtInZoomControls = true
            displayZoomControls = false
        }
        
        // 添加JavaScript接口用于文件读取
        webView.addJavascriptInterface(AndroidFileReader(), "AndroidFileReader")
        
        webView.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(
                view: WebView?,
                request: WebResourceRequest?
            ): Boolean {
                return false
            }
            
            override fun onPageFinished(view: WebView?, url: String?) {
                super.onPageFinished(view, url)
                Log.d("DocumentViewer", "页面加载完成: $url")
            }
            
            override fun onReceivedError(
                view: WebView?,
                request: WebResourceRequest?,
                error: WebResourceError?
            ) {
                super.onReceivedError(view, request, error)
                Log.e("WebView", "Error loading: ${error?.description}")
            }
        }
    }
    
    private fun loadDocument(filePath: String) {
        try {
            // URL编码文件路径（重要：处理中文和特殊字符）
            val encodedPath = Uri.encode(filePath, "UTF-8")
            val url = "file:///android_asset/doc/index.html#/document-viewer?file=$encodedPath"
            
            Log.d("DocumentViewer", "Loading URL: $url")
            Log.d("DocumentViewer", "Original file path: $filePath")
            Log.d("DocumentViewer", "Encoded file path: $encodedPath")
            
            webView.loadUrl(url)
        } catch (e: Exception) {
            Log.e("DocumentViewer", "Error loading document: ${e.message}")
        }
    }
    
    // JavaScript接口类，用于读取本地文件
    private inner class AndroidFileReader {
        @JavascriptInterface
        fun readFile(filePath: String) {
            Log.d("AndroidFileReader", "开始读取文件: $filePath")
            
            Thread {
                try {
                    val file = File(filePath)
                    if (!file.exists()) {
                        Log.e("AndroidFileReader", "文件不存在: $filePath")
                        runOnUiThread {
                            webView.evaluateJavascript("window.onFileReadError('文件不存在: $filePath')", null)
                        }
                        return@Thread
                    }
                    
                    if (!file.canRead()) {
                        Log.e("AndroidFileReader", "没有文件读取权限: $filePath")
                        runOnUiThread {
                            webView.evaluateJavascript("window.onFileReadError('没有文件读取权限: $filePath')", null)
                        }
                        return@Thread
                    }
                    
                    Log.d("AndroidFileReader", "文件大小: ${file.length()} bytes")
                    
                    // 读取文件并转换为base64
                    val fileBytes = file.readBytes()
                    val base64Data = Base64.encodeToString(fileBytes, Base64.NO_WRAP)
                    
                    Log.d("AndroidFileReader", "文件读取成功，base64长度: ${base64Data.length}")
                    
                    // 回调JavaScript
                    runOnUiThread {
                        webView.evaluateJavascript("window.onFileReadSuccess('$base64Data')", null)
                    }
                    
                } catch (e: Exception) {
                    Log.e("AndroidFileReader", "读取文件失败: $filePath", e)
                    runOnUiThread {
                        webView.evaluateJavascript("window.onFileReadError('读取文件异常: ${e.message}')", null)
                    }
                }
            }.start()
        }
    }
    
    override fun onBackPressed() {
        if (webView.canGoBack()) {
            webView.goBack()
        } else {
            super.onBackPressed()
        }
    }
}