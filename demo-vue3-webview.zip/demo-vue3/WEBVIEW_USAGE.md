# Vue文档查看器 - Android WebView集成指南

## 项目概述
这是一个Vue 3项目，专门为Android WebView设计，支持通过URL参数加载本地的docx和pptx文件进行预览。

## 功能特性
- 支持docx文件预览（使用@vue-office/docx）
- 支持pptx文件预览（使用@vue-office/pptx）
- 通过URL参数动态加载本地文件
- 适配Android WebView环境
- 响应式设计，适合移动端显示

## 构建和部署

### 1. 安装依赖
```bash
npm install
# 或
pnpm install
```

### 2. 开发环境运行
```bash
npm run serve
```

### 3. 生产环境构建
```bash
npm run build
```
构建完成后，`dist`目录包含所有静态文件，可以直接部署到Android应用的assets目录。

## Android WebView使用方法

### 1. 基本URL格式
```
file:///android_asset/doc/index.html#/document-viewer?file=文件路径
```

### 2. 示例URL

#### 加载docx文件
```
file:///android_asset/doc/index.html#/document-viewer?file=/storage/emulated/0/Documents/example.docx
```

#### 加载pptx文件
```
file:///android_asset/doc/index.html#/document-viewer?file=/storage/emulated/0/Documents/presentation.pptx
```

#### 使用相对路径
```
file:///android_asset/doc/index.html#/document-viewer?file=./documents/example.docx
```

### 3. Android代码示例

```java
public class DocumentViewerActivity extends AppCompatActivity {
    private WebView webView;
    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_document_viewer);
        
        webView = findViewById(R.id.webview);
        
        // 启用JavaScript
        WebSettings webSettings = webView.getSettings();
        webSettings.setJavaScriptEnabled(true);
        webSettings.setDomStorageEnabled(true);
        webSettings.setAllowFileAccess(true);
        webSettings.setAllowFileAccessFromFileURLs(true);
        webSettings.setAllowUniversalAccessFromFileURLs(true);
        
        // 加载文档
        String filePath = "/storage/emulated/0/Documents/example.docx";
        String url = "file:///android_asset/doc/index.html#/document-viewer?file=" + 
                     Uri.encode(filePath);
        webView.loadUrl(url);
    }
}
```

### 4. 权限配置
在AndroidManifest.xml中添加必要权限：
```xml
<uses-permission android:name="android.permission.READ_EXTERNAL_STORAGE" />
<uses-permission android:name="android.permission.INTERNET" />
```

## 文件路径说明

### 支持的路径格式
1. **绝对路径**: `/storage/emulated/0/Documents/file.docx`
2. **相对路径**: `./documents/file.docx`
3. **file://协议**: `file:///storage/emulated/0/Documents/file.docx`

### 支持的文件类型
- `.docx` - Microsoft Word文档
- `.pptx` - Microsoft PowerPoint演示文稿

## 错误处理
- 文件不存在：显示文件加载失败提示
- 不支持的文件类型：显示不支持的文件类型提示
- 网络错误：显示相应的错误信息

## 开发注意事项

### 1. 跨域问题
在开发环境中，已配置CORS头部允许跨域访问。

### 2. 文件访问权限
确保Android应用有足够的权限访问目标文件。

### 3. 内存优化
大文件可能导致内存问题，建议：
- 限制文件大小
- 实现文件预加载检查
- 添加内存监控

### 4. 性能优化
- 生产构建已禁用source map
- 实现了代码分割
- 静态资源优化

## 自定义配置

### 修改默认样式
编辑 `src/components/DocumentViewer.vue` 中的样式部分。

### 添加新的文件类型支持
1. 安装相应的vue-office组件
2. 在DocumentViewer.vue中添加新的文件类型判断
3. 添加对应的预览组件

### 修改错误提示
在DocumentViewer.vue的template部分修改错误提示内容。

## 故障排除

### 常见问题
1. **文件无法加载**: 检查文件路径和权限
2. **页面空白**: 检查JavaScript是否启用
3. **样式异常**: 检查CSS文件是否正确加载

### 调试方法
1. 启用WebView调试：`WebView.setWebContentsDebuggingEnabled(true)`
2. 使用Chrome DevTools连接调试
3. 查看控制台日志输出