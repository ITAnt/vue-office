<template>
   <div v-loading="loading">
       <vue-office-pptx
           :src="pptx"
           style="height: 100vh;"
           @rendered="renderedHandler"
           @error="errorHandler"
       />
   </div>
</template>

<script>
//引入VueOfficePptx组件
import VueOfficePptx from '@vue-office/pptx'

export default {
    name: "VueOfficePptxDemo",
    components: {
        VueOfficePptx
    },
    data() {
        return {
            loading: true,
            pptx: 'http://static.shanhuxueyuan.com/test.pptx'
        }
    },
    methods: {
        renderedHandler() {
            this.loading = false;
            console.log("渲染完成")
        },
        errorHandler() {
            this.loading = false;
            console.log("渲染失败")
        }
    }
};
</script>

<style scoped>

</style>