<template>
  <div v-loading="loading" class="document-viewer">
    <!-- DOCX 文件预览 -->
    <vue-office-docx
      v-if="fileType === 'docx'"
      :src="fileContent"
      style="height: 100vh;"
      @rendered="renderedHandler"
      @error="errorHandler"
    />
    
    <!-- PPTX 文件预览 -->
    <vue-office-pptx
      v-if="fileType === 'pptx'"
      :src="fileContent"
      style="height: 100vh;"
      @rendered="renderedHandler"
      @error="errorHandler"
    />
    
    <!-- 错误提示 -->
    <div v-if="error" class="error-message">
      <h3>文件加载失败</h3>
      <p>{{ errorMessage }}</p>
      <p>请检查文件路径是否正确：{{ filePath }}</p>
    </div>
    
    <!-- 不支持的文件类型 -->
    <div v-if="!fileType && filePath && !loading" class="unsupported-message">
      <h3>不支持的文件类型</h3>
      <p>当前仅支持 .docx 和 .pptx 文件</p>
      <p>文件路径：{{ filePath }}</p>
    </div>
  </div>
</template>

<script>
import VueOfficeDocx from '@vue-office/docx'
import '@vue-office/docx/lib/index.css'
import VueOfficePptx from '@vue-office/pptx'

export default {
  name: "DocumentViewer",
  components: {
    VueOfficeDocx,
    VueOfficePptx
  },
  data() {
    return {
      loading: false,
      fileContent: null,
      fileType: null,
      filePath: '',
      error: false,
      errorMessage: ''
    }
  },
  mounted() {
    // 注册全局回调方法供Android调用
    window.onFileReadSuccess = this.onFileReadSuccess
    window.onFileReadError = this.onFileReadError
    
    // 动态加载全屏CSS
    this.loadFullscreenCSS()
    
    this.loadFileFromUrl()
  },
  
  beforeUnmount() {
    // 清理全局回调方法
    delete window.onFileReadSuccess
    delete window.onFileReadError
  },
  watch: {
    '$route'() {
      this.loadFileFromUrl()
    }
  },
  methods: {
    loadFileFromUrl() {
      // 从URL参数获取文件路径（支持hash模式的参数）
      let filePath = null
      
      // 尝试从Vue Router的query参数获取
      if (this.$route && this.$route.query) {
        filePath = this.$route.query.file || this.$route.query.path
      }
      
      // 如果Vue Router没有获取到，尝试从hash中解析
      if (!filePath) {
        const hash = window.location.hash
        const queryStart = hash.indexOf('?')
        if (queryStart !== -1) {
          const queryString = hash.substring(queryStart + 1)
          const urlParams = new URLSearchParams(queryString)
          filePath = urlParams.get('file') || urlParams.get('path')
        }
      }
      
      // 如果还是没有，尝试从search参数获取
      if (!filePath) {
        const urlParams = new URLSearchParams(window.location.search)
        filePath = urlParams.get('file') || urlParams.get('path')
      }
      
      if (!filePath) {
        this.error = true
        this.errorMessage = '未提供文件路径参数。请在URL中添加 ?file=文件路径 或 ?path=文件路径'
        console.log('URL解析调试信息:', {
          hash: window.location.hash,
          search: window.location.search,
          route: this.$route
        })
        return
      }
      
      // 解码文件路径（处理URL编码的特殊字符）
      try {
        filePath = decodeURIComponent(filePath)
      } catch (e) {
        console.warn('文件路径解码失败:', e)
      }
      
      this.filePath = filePath
      this.error = false
      this.errorMessage = ''
      
      // 判断文件类型
      const extension = filePath.toLowerCase().split('.').pop()
      if (extension === 'docx') {
        this.fileType = 'docx'
      } else if (extension === 'pptx') {
        this.fileType = 'pptx'
      } else {
        this.fileType = null
        return
      }
      
      this.loadLocalFile(filePath)
    },
    
    async loadLocalFile(filePath) {
      this.loading = true
      
      try {
        // 检测是否在Android WebView环境中
        const isAndroid = /Android/i.test(navigator.userAgent)
        const isWebView = window.AndroidFileReader !== undefined
        
        if (isAndroid && isWebView) {
          // 在Android WebView中，使用JavaScriptInterface读取文件
          console.log('使用Android JavaScriptInterface读取文件:', filePath)
          this.loadFileViaAndroidInterface(filePath)
        } else {
          // 在普通浏览器中，尝试使用fetch
          await this.loadFileViaFetch(filePath)
        }
        
      } catch (error) {
        console.error('文件加载失败:', error)
        this.error = true
        this.errorMessage = `文件加载失败: ${error.message}`
        this.loading = false
      }
    },
    
    async loadFileViaFetch(filePath) {
      // 在普通浏览器中使用fetch（主要用于开发测试）
      let fileUrl = filePath
      
      // 如果路径不是以协议开头，添加file://协议
      if (!filePath.startsWith('http://') && !filePath.startsWith('https://') && !filePath.startsWith('file://')) {
        fileUrl = 'file://' + filePath
      }
      
      const response = await fetch(fileUrl)
      
      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`)
      }
      
      // 读取为ArrayBuffer
      const arrayBuffer = await response.arrayBuffer()
      this.fileContent = arrayBuffer
    },
    
    loadFileViaAndroidInterface(filePath) {
      // 使用Android JavaScriptInterface读取文件
      if (window.AndroidFileReader && window.AndroidFileReader.readFile) {
        try {
          // 调用Android方法读取文件
          window.AndroidFileReader.readFile(filePath)
        } catch (error) {
          throw new Error(`Android文件读取失败: ${error.message}`)
        }
      } else {
        throw new Error('AndroidFileReader接口未找到，请检查Android代码配置')
      }
    },
    
    // 供Android调用的回调方法
    onFileReadSuccess(base64Data) {
      try {
        // 将base64转换为ArrayBuffer
        const binaryString = atob(base64Data)
        const bytes = new Uint8Array(binaryString.length)
        for (let i = 0; i < binaryString.length; i++) {
          bytes[i] = binaryString.charCodeAt(i)
        }
        this.fileContent = bytes.buffer
        this.loading = false
      } catch (error) {
        console.error('文件数据处理失败:', error)
        this.error = true
        this.errorMessage = `文件数据处理失败: ${error.message}`
        this.loading = false
      }
    },
    
    // 供Android调用的错误回调方法
    onFileReadError(errorMessage) {
      console.error('Android文件读取失败:', errorMessage)
      this.error = true
      this.errorMessage = `文件读取失败: ${errorMessage}`
      this.loading = false
    },
    
    // 加载全屏CSS
    loadFullscreenCSS() {
      // 动态添加全屏样式
      const style = document.createElement('style')
      style.textContent = `
        html, body {
          margin: 0 !important;
          padding: 0 !important;
          width: 100% !important;
          height: 100% !important;
          overflow: hidden !important;
          background: white !important;
        }
        
        #app {
          margin: 0 !important;
          padding: 0 !important;
          width: 100% !important;
          height: 100% !important;
        }
        
        .vue-office-docx,
        .vue-office-pptx {
          width: 100vw !important;
          height: 100vh !important;
          margin: 0 !important;
          padding: 0 !important;
          border: none !important;
          outline: none !important;
        }
      `
      document.head.appendChild(style)
    },
    
    renderedHandler() {
      this.loading = false
      console.log("文档渲染完成")
    },
    
    errorHandler(error) {
      this.loading = false
      this.error = true
      this.errorMessage = '文档渲染失败'
      console.error("文档渲染失败:", error)
    }
  }
}
</script>

<style scoped>
.document-viewer {
  width: 100vw;
  height: 100vh;
  margin: 0;
  padding: 0;
  border: none;
  outline: none;
  background: white;
  position: relative;
}

/* 确保vue-office组件也是全屏 */
.document-viewer :deep(.vue-office-docx),
.document-viewer :deep(.vue-office-pptx) {
  width: 100% !important;
  height: 100vh !important;
  margin: 0 !important;
  padding: 0 !important;
  border: none !important;
}

.error-message,
.unsupported-message {
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  height: 100vh;
  width: 100vw;
  text-align: center;
  padding: 20px;
  margin: 0;
  background: white;
}

.error-message h3,
.unsupported-message h3 {
  color: #e74c3c;
  margin-bottom: 10px;
}

.error-message p,
.unsupported-message p {
  margin: 5px 0;
  color: #666;
}
</style>