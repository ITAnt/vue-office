<template>
    <div id="app-wrapper" :class="{ 'fullscreen': isFullscreenRoute }">
        <div v-if="!isFullscreenRoute" class="menu-area">
            <el-menu :default-active="defaultActive" @select="changeMenu">
                <el-menu-item
                    v-for="item in menus"
                    :index="item.index"
                    :key="item.index"
                >{{ item.label }}
                </el-menu-item>
            </el-menu>
        </div>
        <div class="main-content" :class="{ 'fullscreen-content': isFullscreenRoute }">
            <router-view/>
        </div>
    </div>
</template>

<script>
export default {
    name: 'App',
    components: {},
    data() {
        return {
            menus: [
                {
                    label: 'docx预览（VueOfficeDocx）',
                    index: '/vue-office-docx'
                },
                {
                    label: 'pptx预览（VueOfficePptx）',
                    index: '/vue-office-pptx'
                },
                {
                    label: 'excel预览（VueOfficeExcel）',
                    index: '/vue-office-excel'
                },
                {
                    label: 'pdf预览（VueOfficePdf）',
                    index: '/vue-office-pdf'
                },
                {
                    label: '文档查看器（URL参数）',
                    index: '/document-viewer'
                },
                {
                    label: 'docx预览（纯js预览）',
                    index: '/js-preview-docx'
                },
                {
                    label: 'excel预览（纯js预览）',
                    index: '/js-preview-excel'
                },
                {
                    label: 'pdf预览（纯js预览）',
                    index: '/js-preview-pdf'
                }
            ],
            defaultActive: '/vue-office-docx',
            // 需要全屏显示的路由列表
            fullscreenRoutes: ['/document-viewer'],
            // 初始化时就判断是否为全屏路由，避免闪现
            isFullscreen: false
        };
    },
    computed: {
        // 判断当前路由是否需要全屏显示
        isFullscreenRoute() {
            return this.isFullscreen || this.fullscreenRoutes.includes(this.$route.path)
        }
    },
    created() {
        // 在组件创建时就判断路由，避免菜单闪现
        this.checkFullscreenRoute();
    },
    mounted() {
        let path = location.hash.match(/^#(\/.*?)(\?|$)/)[1];
        this.defaultActive = path === '/' ? '/vue-office-docx' : path;
    },
    watch: {
        '$route'() {
            this.checkFullscreenRoute();
        }
    },
    methods: {
        changeMenu(index) {
            this.$router.push(index);
        },
        checkFullscreenRoute() {
            // 从URL hash中解析路径
            const hash = window.location.hash;
            const pathMatch = hash.match(/^#(\/[^?]*)/);
            const currentPath = pathMatch ? pathMatch[1] : '/';
            
            // 检查是否为全屏路由
            this.isFullscreen = this.fullscreenRoutes.includes(currentPath);
        }
    }
};
</script>

<style>
* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
}

body {
    margin: 0;
    padding: 0;
    overflow: hidden;
}

#app-wrapper {
    display: flex;
    width: 100vw;
    height: 100vh;
    margin: 0;
    padding: 0;
}

#app-wrapper.fullscreen {
    display: block;
}

.menu-area{
    width: 230px;
    height: 100vh;
    background: #f5f5f5;
    border-right: 1px solid #e0e0e0;
}

.main-content {
    flex: 1;
    height: 100vh;
    overflow-y: auto;
    background: white;
}

.main-content.fullscreen-content {
    width: 100vw;
    height: 100vh;
    overflow: hidden;
    background: white;
    margin: 0;
    padding: 0;
}
</style>
