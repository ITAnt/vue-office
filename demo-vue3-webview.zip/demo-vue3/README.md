# Vue文档查看器 - Android WebView版

一个专为Android WebView设计的Vue 3文档查看器，支持通过URL参数动态加载本地的docx和pptx文件。

## 🚀 快速开始

### 1. 构建项目
```bash
npm install
npm run build
```

### 2. 部署到Android
运行部署脚本（Windows）：
```bash
deploy-to-android.bat
```

或手动复制 `dist` 目录中的所有文件到Android项目的 `src/main/assets/doc` 目录。

### 3. Android集成
```kotlin
// 配置WebView
webView.settings.apply {
    javaScriptEnabled = true
    domStorageEnabled = true
    allowFileAccess = true
    allowFileAccessFromFileURLs = true
    allowUniversalAccessFromFileURLs = true
}

// 添加JavaScript接口（重要！）
webView.addJavascriptInterface(AndroidFileReader(), "AndroidFileReader")

// 加载文档
val filePath = "/storage/emulated/0/Documents/example.docx"
val encodedPath = Uri.encode(filePath, "UTF-8")
val url = "file:///android_asset/doc/index.html#/document-viewer?file=$encodedPath"
webView.loadUrl(url)
```

## 📁 项目结构

```
├── src/
│   ├── components/
│   │   ├── DocumentViewer.vue      # 主文档查看器组件
│   │   ├── VueOfficeDocx.vue       # DOCX预览组件
│   │   └── VueOfficePptx.vue       # PPTX预览组件
│   ├── App.vue                     # 主应用组件
│   ├── main.js                     # 应用入口
│   └── routes.js                   # 路由配置
├── public/
│   └── test.html                   # 测试页面
├── dist/                           # 构建输出目录
├── ANDROID_DEPLOYMENT.md           # 详细部署指南
├── WEBVIEW_USAGE.md               # 使用说明
└── deploy-to-android.bat          # 部署脚本
```

## ✨ 功能特性

- ✅ 支持 `.docx` 文件预览
- ✅ 支持 `.pptx` 文件预览  
- ✅ 通过URL参数动态加载文件
- ✅ 适配Android WebView环境
- ✅ 响应式设计，适合移动端
- ✅ 完善的错误处理和提示
- ✅ 支持多种文件路径格式
- ✅ 全屏显示模式（无左侧菜单）

## 🔧 URL格式

### 基本格式（全屏显示）
```
file:///android_asset/doc/index.html#/document-viewer?file=文件路径
```

> 📱 **全屏模式**: `/document-viewer` 路由会自动隐藏左侧菜单，提供全屏的文档查看体验，特别适合移动设备。

### 示例
```bash
# 绝对路径
file:///android_asset/doc/index.html#/document-viewer?file=/storage/emulated/0/Documents/example.docx

# 相对路径  
file:///android_asset/doc/index.html#/document-viewer?file=./documents/presentation.pptx

# file://协议
file:///android_asset/doc/index.html#/document-viewer?file=file:///storage/emulated/0/Download/document.docx
```

## 📱 Android权限配置

在 `AndroidManifest.xml` 中添加：

```xml
<uses-permission android:name="android.permission.INTERNET" />
<uses-permission android:name="android.permission.READ_EXTERNAL_STORAGE" />
<uses-permission android:name="android.permission.WRITE_EXTERNAL_STORAGE" />
<uses-permission android:name="android.permission.MANAGE_EXTERNAL_STORAGE" />

<application android:usesCleartextTraffic="true" ... >
```

## 🛠 开发

### 启动开发服务器
```bash
npm run serve
```

### 测试
访问 `http://localhost:8080/test.html` 查看测试页面

### 构建
```bash
npm run build
```

## 📖 详细文档

- [Android部署指南](ANDROID_DEPLOYMENT.md) - 完整的Android集成说明
- [使用说明](WEBVIEW_USAGE.md) - 详细的使用方法和API说明

## 🔍 故障排除

### 常见问题

#### 1. Fetch API无法访问本地文件 ⚠️
**问题**: "Fetch API cannot load file://... URL scheme 'file' is not supported"
**解决**: 必须添加JavaScriptInterface
```kotlin
// ✅ 关键步骤
webView.addJavascriptInterface(AndroidFileReader(), "AndroidFileReader")
```

#### 2. 文件路径包含中文或特殊字符
**问题**: 提示"未提供文件路径参数"
**解决**: 确保正确编码文件路径
```kotlin
val encodedPath = Uri.encode(filePath, "UTF-8")
```

#### 2. 其他问题
- **文件无法加载** - 检查文件路径和权限
- **页面空白** - 确认JavaScript已启用
- **样式异常** - 检查CSS文件是否正确加载

### 调试方法
```java
// 启用WebView调试
if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
    WebView.setWebContentsDebuggingEnabled(true);
}
```

然后在Chrome浏览器中访问 `chrome://inspect` 进行调试。

## 📋 系统要求

- **Android**: API 21+ (Android 5.0+)
- **WebView**: Chrome 60+
- **文件格式**: .docx, .pptx

## 🤝 贡献

欢迎提交Issue和Pull Request来改进这个项目！

## 📄 许可证

MIT License