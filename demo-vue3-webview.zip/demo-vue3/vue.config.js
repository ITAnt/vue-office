const { defineConfig } = require('@vue/cli-service')
module.exports = defineConfig({
  transpileDependencies: true,
  // 配置公共路径，适用于WebView，放在assets/doc目录下
  publicPath: './',
  // 输出目录
  outputDir: 'dist',
  // 静态资源目录
  assetsDir: 'static',
  // 生产环境不生成source map
  productionSourceMap: false,
  configureWebpack(){
    return {
      resolve: {
        fallback: {
          "util": false,
          "stream": false
        }
      },
      // 优化打包
      optimization: {
        splitChunks: {
          chunks: 'all',
          cacheGroups: {
            vendor: {
              name: 'chunk-vendors',
              test: /[\\/]node_modules[\\/]/,
              priority: 10,
              chunks: 'initial'
            },
            common: {
              name: 'chunk-common',
              minChunks: 2,
              priority: 5,
              chunks: 'initial',
              reuseExistingChunk: true
            }
          }
        }
      }
    }
  },
  // 开发服务器配置
  devServer: {
    port: 8080,
    host: '0.0.0.0',
    // 允许访问本地文件（开发环境）
    headers: {
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, PATCH, OPTIONS',
      'Access-Control-Allow-Headers': 'X-Requested-With, content-type, Authorization'
    }
  }
})
