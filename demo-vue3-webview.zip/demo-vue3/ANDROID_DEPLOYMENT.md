# Android WebView 部署指南

## 构建完成 ✅

项目已成功构建，所有文件都在 `dist` 目录中。

## 🎯 全屏文档查看器

**重要特性**: `/document-viewer` 路由会自动提供全屏显示模式：
- ✅ 自动隐藏左侧菜单
- ✅ 文档占满整个屏幕
- ✅ 沉浸式阅读体验
- ✅ 特别适合移动设备和WebView

## 部署步骤

### 1. 复制文件到Android项目
将 `dist` 目录中的所有文件复制到你的Android项目的 `src/main/assets/doc` 目录：

```
your-android-project/
├── src/
│   └── main/
│       └── assets/
│           └── doc/                # 文档查看器目录
│               ├── index.html      # 主应用文件
│               ├── test.html       # 测试页面
│               ├── favicon.ico     # 图标
│               └── static/         # 静态资源目录
│                   ├── css/        # 样式文件
│                   └── js/         # JavaScript文件
```

### 2. Android WebView配置

#### Java示例代码：
```java
import android.util.Base64;
import android.webkit.JavascriptInterface;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;

public class DocumentViewerActivity extends AppCompatActivity {
    private WebView webView;
    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_document_viewer);
        
        webView = findViewById(R.id.webview);
        setupWebView();
        
        // 获取要显示的文件路径（从Intent或其他方式）
        String filePath = getIntent().getStringExtra("file_path");
        if (filePath != null) {
            loadDocument(filePath);
        }
    }
    
    private void setupWebView() {
        WebSettings webSettings = webView.getSettings();
        
        // 启用JavaScript
        webSettings.setJavaScriptEnabled(true);
        
        // 启用DOM存储
        webSettings.setDomStorageEnabled(true);
        
        // 允许文件访问
        webSettings.setAllowFileAccess(true);
        webSettings.setAllowFileAccessFromFileURLs(true);
        webSettings.setAllowUniversalAccessFromFileURLs(true);
        
        // 设置缓存模式
        webSettings.setCacheMode(WebSettings.LOAD_DEFAULT);
        
        // 启用缩放
        webSettings.setSupportZoom(true);
        webSettings.setBuiltInZoomControls(true);
        webSettings.setDisplayZoomControls(false);
        
        // 添加JavaScript接口用于文件读取
        webView.addJavascriptInterface(new AndroidFileReader(), "AndroidFileReader");
        
        // 设置WebViewClient
        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                return false;
            }
            
            @Override
            public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                // 页面加载完成
            }
            
            @Override
            public void onReceivedError(WebView view, WebResourceRequest request, 
                                      WebResourceError error) {
                super.onReceivedError(view, request, error);
                // 处理加载错误
                Log.e("WebView", "Error loading: " + error.getDescription());
            }
        });
    }
    
    private void loadDocument(String filePath) {
        try {
            // URL编码文件路径（重要：处理中文和特殊字符）
            String encodedPath = Uri.encode(filePath, "UTF-8");
            
            // 构建完整URL（注意路径包含doc目录）
            String url = "file:///android_asset/doc/index.html#/document-viewer?file=" + encodedPath;
            
            Log.d("DocumentViewer", "Loading URL: " + url);
            Log.d("DocumentViewer", "Original file path: " + filePath);
            Log.d("DocumentViewer", "Encoded file path: " + encodedPath);
            
            // 加载URL
            webView.loadUrl(url);
            
        } catch (Exception e) {
            Log.e("DocumentViewer", "Error loading document: " + e.getMessage());
            // 显示错误提示
        }
    }
    
    // JavaScript接口类，用于读取本地文件
    private class AndroidFileReader {
        @JavascriptInterface
        public void readFile(String filePath) {
            new Thread(() -> {
                try {
                    File file = new File(filePath);
                    if (!file.exists()) {
                        runOnUiThread(() -> {
                            webView.evaluateJavascript("window.onFileReadError('文件不存在: " + filePath + "')", null);
                        });
                        return;
                    }
                    
                    if (!file.canRead()) {
                        runOnUiThread(() -> {
                            webView.evaluateJavascript("window.onFileReadError('没有文件读取权限: " + filePath + "')", null);
                        });
                        return;
                    }
                    
                    // 读取文件并转换为base64
                    FileInputStream fis = new FileInputStream(file);
                    ByteArrayOutputStream baos = new ByteArrayOutputStream();
                    byte[] buffer = new byte[8192];
                    int bytesRead;
                    
                    while ((bytesRead = fis.read(buffer)) != -1) {
                        baos.write(buffer, 0, bytesRead);
                    }
                    
                    fis.close();
                    byte[] fileBytes = baos.toByteArray();
                    String base64Data = Base64.encodeToString(fileBytes, Base64.NO_WRAP);
                    
                    // 回调JavaScript
                    runOnUiThread(() -> {
                        webView.evaluateJavascript("window.onFileReadSuccess('" + base64Data + "')", null);
                    });
                    
                } catch (Exception e) {
                    Log.e("AndroidFileReader", "读取文件失败", e);
                    runOnUiThread(() -> {
                        webView.evaluateJavascript("window.onFileReadError('读取文件异常: " + e.getMessage() + "')", null);
                    });
                }
            }).start();
        }
    }
    
    @Override
    public void onBackPressed() {
        if (webView.canGoBack()) {
            webView.goBack();
        } else {
            super.onBackPressed();
        }
    }
}
```

#### Kotlin示例代码：
```kotlin
import android.util.Base64
import android.webkit.JavascriptInterface
import java.io.File

class DocumentViewerActivity : AppCompatActivity() {
    private lateinit var webView: WebView
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_document_viewer)
        
        webView = findViewById(R.id.webview)
        setupWebView()
        
        // 获取要显示的文件路径
        intent.getStringExtra("file_path")?.let { filePath ->
            loadDocument(filePath)
        }
    }
    
    private fun setupWebView() {
        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            allowFileAccess = true
            allowFileAccessFromFileURLs = true
            allowUniversalAccessFromFileURLs = true
            cacheMode = WebSettings.LOAD_DEFAULT
            setSupportZoom(true)
            builtInZoomControls = true
            displayZoomControls = false
        }
        
        // 添加JavaScript接口用于文件读取
        webView.addJavascriptInterface(AndroidFileReader(), "AndroidFileReader")
        
        webView.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(
                view: WebView?,
                request: WebResourceRequest?
            ): Boolean {
                return false
            }
            
            override fun onPageFinished(view: WebView?, url: String?) {
                super.onPageFinished(view, url)
                // 页面加载完成
            }
            
            override fun onReceivedError(
                view: WebView?,
                request: WebResourceRequest?,
                error: WebResourceError?
            ) {
                super.onReceivedError(view, request, error)
                Log.e("WebView", "Error loading: ${error?.description}")
            }
        }
    }
    
    private fun loadDocument(filePath: String) {
        try {
            // URL编码文件路径（重要：处理中文和特殊字符）
            val encodedPath = Uri.encode(filePath, "UTF-8")
            val url = "file:///android_asset/doc/index.html#/document-viewer?file=$encodedPath"
            
            Log.d("DocumentViewer", "Loading URL: $url")
            Log.d("DocumentViewer", "Original file path: $filePath")
            Log.d("DocumentViewer", "Encoded file path: $encodedPath")
            
            webView.loadUrl(url)
        } catch (e: Exception) {
            Log.e("DocumentViewer", "Error loading document: ${e.message}")
        }
    }
    
    // JavaScript接口类，用于读取本地文件
    private inner class AndroidFileReader {
        @JavascriptInterface
        fun readFile(filePath: String) {
            Thread {
                try {
                    val file = File(filePath)
                    if (!file.exists()) {
                        runOnUiThread {
                            webView.evaluateJavascript("window.onFileReadError('文件不存在: $filePath')", null)
                        }
                        return@Thread
                    }
                    
                    if (!file.canRead()) {
                        runOnUiThread {
                            webView.evaluateJavascript("window.onFileReadError('没有文件读取权限: $filePath')", null)
                        }
                        return@Thread
                    }
                    
                    // 读取文件并转换为base64
                    val fileBytes = file.readBytes()
                    val base64Data = Base64.encodeToString(fileBytes, Base64.NO_WRAP)
                    
                    // 回调JavaScript
                    runOnUiThread {
                        webView.evaluateJavascript("window.onFileReadSuccess('$base64Data')", null)
                    }
                    
                } catch (e: Exception) {
                    Log.e("AndroidFileReader", "读取文件失败", e)
                    runOnUiThread {
                        webView.evaluateJavascript("window.onFileReadError('读取文件异常: ${e.message}')", null)
                    }
                }
            }.start()
        }
    }
    
    override fun onBackPressed() {
        if (webView.canGoBack()) {
            webView.goBack()
        } else {
            super.onBackPressed()
        }
    }
}
```

### 3. 布局文件 (activity_document_viewer.xml)
```xml
<?xml version="1.0" encoding="utf-8"?>
<LinearLayout xmlns:android="http://schemas.android.com/apk/res/android"
    android:layout_width="match_parent"
    android:layout_height="match_parent"
    android:orientation="vertical">
    
    <WebView
        android:id="@+id/webview"
        android:layout_width="match_parent"
        android:layout_height="match_parent" />
        
</LinearLayout>
```

### 4. 权限配置 (AndroidManifest.xml)
```xml
<uses-permission android:name="android.permission.INTERNET" />
<uses-permission android:name="android.permission.READ_EXTERNAL_STORAGE" />
<uses-permission android:name="android.permission.WRITE_EXTERNAL_STORAGE" />

<!-- Android 10+ 需要的权限 -->
<uses-permission android:name="android.permission.MANAGE_EXTERNAL_STORAGE" />

<application
    android:usesCleartextTraffic="true"
    ... >
    
    <activity
        android:name=".DocumentViewerActivity"
        android:exported="true"
        android:theme="@style/Theme.AppCompat.Light.NoActionBar" />
        
</application>
```

## 使用方法

### 1. 基本调用
```java
Intent intent = new Intent(this, DocumentViewerActivity.class);
intent.putExtra("file_path", "/storage/emulated/0/Documents/example.docx");
startActivity(intent);
```

### 2. 支持的文件路径格式
- **绝对路径**: `/storage/emulated/0/Documents/file.docx`
- **相对路径**: `./documents/file.docx`
- **应用内部存储**: `/data/data/com.yourapp/files/document.docx`

### 3. 支持的文件类型
- `.docx` - Microsoft Word文档
- `.pptx` - Microsoft PowerPoint演示文稿

## 测试方法

### 1. 使用测试页面
在浏览器中打开：`file:///android_asset/doc/test.html`

### 2. 直接测试URL
```
file:///android_asset/doc/index.html#/document-viewer?file=/path/to/your/file.docx
```

## 常见问题解决

### 1. Fetch API无法加载file://协议文件 ⚠️
**问题**: 控制台显示 "Fetch API cannot load file://... URL scheme 'file' is not supported"
**原因**: Android WebView出于安全考虑，禁止JavaScript直接访问file://协议的本地文件
**解决方案**: 必须添加JavaScriptInterface来读取本地文件

**检查清单**:
- ✅ 确认已添加 `webView.addJavascriptInterface(AndroidFileReader(), "AndroidFileReader")`
- ✅ 确认AndroidFileReader类已正确实现
- ✅ 确认已添加 `@JavascriptInterface` 注解
- ✅ 确认应用有文件读取权限

### 2. 文件路径包含中文或特殊字符
**问题**: 提示"未提供文件路径参数"，但URL中明确包含file参数
**原因**: 文件路径包含中文、空格等特殊字符没有正确编码
**解决方案**:
```kotlin
// ❌ 错误的做法
val url = "file:///android_asset/doc/index.html#/document-viewer?file=$filePath"

// ✅ 正确的做法
val encodedPath = Uri.encode(filePath, "UTF-8")
val url = "file:///android_asset/doc/index.html#/document-viewer?file=$encodedPath"
```

### 3. JavaScriptInterface未找到
**问题**: 控制台显示 "AndroidFileReader接口未找到"
**解决方案**: 
```kotlin
// 确保在setupWebView()中添加了接口
webView.addJavascriptInterface(AndroidFileReader(), "AndroidFileReader")
```

### 4. 文件读取权限问题
**问题**: 提示"没有文件读取权限"
**解决方案**:
- 确认AndroidManifest.xml中已添加权限
- 对于Android 6.0+，需要动态请求权限
- 对于Android 11+，可能需要MANAGE_EXTERNAL_STORAGE权限

### 5. 文件不存在
**问题**: 提示"文件不存在"
**解决方案**:
- 检查文件路径是否正确
- 确认文件确实存在于指定位置
- 验证文件格式是否支持（.docx, .pptx）

### 6. 页面显示空白
- 确认JavaScript已启用
- 检查控制台是否有错误信息
- 确认WebView设置正确
- 检查assets目录中的文件是否完整

### 7. 样式显示异常
- 确认CSS文件已正确复制到assets目录
- 检查网络连接（如果使用在线资源）
- 验证static目录结构是否正确

### 8. 性能问题
- 大文件可能导致内存不足
- 建议限制文件大小（< 50MB）
- 考虑实现文件预加载检查

## 调试方法

### 1. 启用WebView调试
```java
if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
    WebView.setWebContentsDebuggingEnabled(true);
}
```

### 2. 使用Chrome DevTools
1. 在Chrome浏览器中打开 `chrome://inspect`
2. 连接Android设备
3. 选择对应的WebView进行调试

### 3. 查看日志
```java
Log.d("DocumentViewer", "Loading file: " + filePath);
```

## 优化建议

### 1. 预加载检查
```java
private boolean isFileValid(String filePath) {
    File file = new File(filePath);
    return file.exists() && file.canRead() && file.length() > 0;
}
```

### 2. 错误处理
```java
private void showError(String message) {
    Toast.makeText(this, "文档加载失败: " + message, Toast.LENGTH_LONG).show();
}
```

### 3. 进度指示
```java
private void showLoading() {
    // 显示加载进度
}

private void hideLoading() {
    // 隐藏加载进度
}
```

## 版本兼容性

- **最低Android版本**: API 21 (Android 5.0)
- **推荐Android版本**: API 24+ (Android 7.0+)
- **WebView版本**: Chrome 60+

构建的应用已经过优化，可以在大多数现代Android设备上正常运行。